from turtle import Turtle, Screen


tim = Turtle()
tim.shape('turtle')
# -------------------------------------------------------
# n_of_side = 3
# color = [
#     '','','',
#     'dark turquoise',
#     'teal',
#     'green',
#     'olive',
#     'goldenrod',
#     'tomato',
#     'dark orchid',
#     'rosy brown',
#     'hot pink',
#     'dodger blue',
# ]
# for j in range(3,12):
#     tim.color(color[n_of_side])
#     for i in range(n_of_side):
#         tim.fd(35)
#         tim.right(360/n_of_side)
#     n_of_side += 1

# -----------------------------------------------------

# import random as rd
# import turtle

# tim.pensize(15)
# tim.speed('fastest')
# direction = [0, 90, 180, 270]
# turtle.colormode(255)

# def ran_color():
#     r = rd.randint(0,255)
#     g = rd.randint(0,255)
#     b = rd.randint(0,255)
#     colors = (r,g,b)
#     return colors

# for _ in range(200):
#     tim.color(ran_color())
#     tim.fd(30)
#     tim.setheading(rd.choice(direction))

# -----------------------------------------------------------

# import turtle as t, random as rd

# tim.speed('fastest')
# t.colormode(255)

# def ran_color():
#     r = rd.randint(0,255)
#     g = rd.randint(0,255)
#     b = rd.randint(0,255)
#     colors = (r,g,b)
#     return colors

# def draw_spirograph(size_of_gap):
#     for _ in range(int(360/size_of_gap)):
#         tim.color(ran_color())
#         tim.circle(100)
#         tim.setheading(tim.heading()+ size_of_gap)

# draw_spirograph(5)

# -----------------------------------------------------------
















screen = Screen()
screen.exitonclick()
