
class Question:
    def __init__(self, q_text, q_ans) -> None:
        self.text = q_text
        self.ans = q_ans

