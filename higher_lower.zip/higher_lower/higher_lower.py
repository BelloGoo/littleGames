from game_data import data
from art import logo, vs
import random as rd
import os

score = 0
actual_ans = 0
ans = 0
round = 2
# ## loop the game whenever player wins; show current scores
# while True:
#   if ans != actual_ans:
#     break

## end thegame whenever player loses; show final scores
def round_check():
   return 49 - round

## get random number
def get_ran_num():
  if round_check() == 0:
     return data
  ran_num = rd.randint(0, round_check())
  ## use the ran num to indicate the item from the list of data (each dictionary is an item from that list)(each dicttionary represent the description of that particular man)
  return data[ran_num]

def judge(ans, score):
   global actual_ans
   if dictA['follower_count'] > dictB['follower_count']:
      actual_ans = 'A'
   elif dictB['follower_count'] > dictA['follower_count']:
      actual_ans = 'B'
   if actual_ans == ans:
      score += 1
      print("Your're right! Current score: {}".format(score))
      return score#, actual_ans
   else: 
      print("Sorry, that's wrong. Final score: {}".format(score))

def ABswitching(dictA, dictB):
   if dictA['follower_count'] > dictB['follower_count']:
      actual_ans = 'A'
   elif dictB['follower_count'] > dictA['follower_count']:
      actual_ans = 'B'
   if actual_ans == 'B':
      dictA = dictB
   return dictA

def remove_data(n):
   '''n is the value in data(data type: list)'''
   data.remove(n)

 # loop the game whenever player wins; show current scores

def clear():
   os.system('clear')

dictA = get_ran_num()
dictB = get_ran_num()
remove_data(dictA)
remove_data(dictB)
while True:
   # if score == 49:
   #    print("OMG! You beated the game TT. You WIN!!")
      # break
   if ans != actual_ans:
      break
## end thegame whenever player loses; show final scores
## print the statment of compare A ... against B ...
   else:
      print(logo)
      print("Compare A: {}, {}, {}.".format(dictA['name'], dictA['description'], dictA['country']))
      # print(dictA['follower_count'])
      print(vs)
      print("Against B: {}, {}, {}.".format(dictB['name'], dictB['description'], dictB['country']))
      # print(dictB['follower_count'])
      ans = input("Who has more followers? Type 'A' or 'B': ")
      ##make a judgement func to check the ans
      score = judge(ans, score)
      dictA = ABswitching(dictA, dictB)
      # print(len(data))
      if len(data) == 1:
         dictB = data[0]
      elif len(data) < 1:
         print("OMG! You beated the game TT. You WIN!!")
         break
      else:
         dictB = get_ran_num()
      remove_data(dictB)
      round += 1
      print('----------------------------------------------------------------------------')
      
   
      ## then the correct one become A, then B